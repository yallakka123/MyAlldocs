#!/bin/bash

TARGET_BRANCH=$1

case "$TARGET_BRANCH" in
  wngmrg)
    echo "env=wngmrg" >> $GITHUB_OUTPUT
    ;;
  sit)
    echo "env=sit" >> $GITHUB_OUTPUT
    ;;
  uat)
    echo "env=uat" >> $GITHUB_OUTPUT
    ;;
  *)
    echo "env=UNKNOWN" >> $GITHUB_OUTPUT
    ;;
esac
